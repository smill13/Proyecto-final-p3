﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proyecto_final_p3.Models;

namespace Proyecto_final_p3.Controllers
{
    [EnableCors("ReglasCors")]
    [Route("api/[controller]")]
    [ApiController]
    public class ReservasController : ControllerBase
    {
        readonly P3FinalContext _finalContext;

        public ReservasController(P3FinalContext finalContext)
        {
            _finalContext = finalContext;
        }

        [HttpGet]
        [Route("Get_Reservas")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetReservas()
        {
            List<Reservas> listReservas = new List<Reservas>();
            listReservas = await _finalContext.Reservas.Include(c=> c.Cliente).Include(x => x.Hotel).ToListAsync();
            return Ok(listReservas);
        }

        [HttpGet]
        [Route("Filtrar_ID")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> FiltrarID(int idReserva)
        {
            try
            {
                Reservas reservas = await _finalContext.Reservas.FirstOrDefaultAsync(p => p.ReservaId == idReserva);

                if (reservas == null)
                {
                    return NotFound("reservae no encontrado");
                }

                return Ok(reservas);
            }
            catch (Exception ex)
            {
                // Registra el error si es necesario
                return StatusCode(StatusCodes.Status500InternalServerError, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("CrearObjeto")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CrearReservas([FromBody] Reservas objeto)
        {
            try
            {
                _finalContext.Reservas.Add(objeto);
                _finalContext.SaveChanges();
                return CreatedAtAction(nameof(FiltrarID), new { Reservas = objeto.ReservaId}, objeto);

            }
            catch (Exception ex)
            {
                return BadRequest($"Error al crear el cliente: {ex.Message}");
            }
        }

        [HttpPatch]
        [Route("EditarObjeto")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateReservas([FromBody] Reservas objeto)
        {
            try
            {
                var existingReservas = await _finalContext.Reservas.FindAsync(objeto.ReservaId);

                if (existingReservas == null)
                {
                    return NotFound($"Reserva con ID {objeto.ReservaId} no encontrado.");
                }

                // Modificar las propiedades del cliente existente con los valores del objeto recibido
                existingReservas.FechaInicio = objeto.FechaInicio;
                existingReservas.FechaFin = objeto.FechaFin;
                existingReservas.PrecioTotal = objeto.PrecioTotal;
                existingReservas.Estado = objeto.Estado;
                existingReservas.ClienteId = objeto.ClienteId;
                existingReservas.HotelId = objeto.HotelId;

                // Guardar los cambios en la base de datos
                _finalContext.SaveChanges();

                // Retornar el cliente actualizado
                return Ok(existingReservas);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al actualizar el cliente: {ex.Message}");
            }
        }

        [HttpDelete]
        [Route("EliminarObjeto")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteReserva(int reservaID)
        {
            try
            {
                // Buscar el reserva por su id
                Reservas reserva = _finalContext.Reservas.FirstOrDefault(c => c.ReservaId == reservaID);

                if (reserva == null)
                {
                    return NotFound($"Reserva con reservaID {reservaID} no encontrada.");
                }

                // Eliminar el reserva de la base de datos
                _finalContext.Reservas.Remove(reserva);
                _finalContext.SaveChanges();

                return Ok("Reserva eliminada exitosamente.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al eliminar la reserva: {ex.Message}");
            }
        }

    }
}

