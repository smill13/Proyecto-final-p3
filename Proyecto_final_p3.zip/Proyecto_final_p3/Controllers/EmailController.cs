﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Proyecto_final_p3.Logic;

namespace Proyecto_final_p3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        [HttpGet]
        [Route("EnviarEmail")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Enviar(string Email, string Asunto, string Mensaje)
        {
            try
            {
                // Lógica para enviar el correo electrónico
                SendEmail.EnviarCorreo(Email, Asunto, Mensaje);

                // Devolver una respuesta exitosa (código 200 OK)
                return Ok("Correo electrónico enviado correctamente.");
            }
            catch (Exception ex)
            {
                // En caso de error, devolver una respuesta de error (código 500 Internal Server Error)
                return StatusCode(500, $"Error al enviar el correo electrónico: {ex.Message}");
            }
        }
    }

}
