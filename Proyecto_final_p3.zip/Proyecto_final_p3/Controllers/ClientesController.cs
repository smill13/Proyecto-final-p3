﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.EntityFrameworkCore;
using Proyecto_final_p3.Models;
using System.ComponentModel;

namespace Proyecto_final_p3.Controllers
{
    [EnableCors("ReglasCors")]
    [Route("api/[controller]")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        readonly P3FinalContext _finalContext;

        public ClientesController(P3FinalContext finalContext)
        {
            _finalContext = finalContext;
                        
        }

        [HttpGet]
        [Route("Get_CLientes")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetClientes()
        {
            List<Cliente> listclientes = new List<Cliente>();
            listclientes = await _finalContext.Clientes.ToListAsync();
          

            return Ok(listclientes);
        }

        [HttpGet]
        [Route("Filtrar_ID")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> FiltrarID(int idCliente)
        {
            try
            {
                Cliente cliente = await _finalContext.Clientes.FirstOrDefaultAsync(p => p.ClienteId == idCliente);

                if (cliente == null)
                {
                    return NotFound("Cliente no encontrado");
                }

                return Ok(cliente);
            }
            catch (Exception ex)
            {
                // Registra el error si es necesario
                return StatusCode(StatusCodes.Status500InternalServerError, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("CrearObjeto")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CrearCliente([FromBody] Cliente objeto)
        {
            try {
                // Validar que el nombre no esté vacío
                if (string.IsNullOrWhiteSpace(objeto.Nombre))
                {
                    return BadRequest("El nombre del cliente no puede estar vacío.");
                }

                // Verificar si ya existe un cliente con el mismo nombre
                bool nombreExistente = _finalContext.Clientes.Any(c => c.Nombre == objeto.Nombre);

                if (nombreExistente)
                {
                    throw new InvalidOperationException("Ya existe un cliente con el mismo nombre.");
                }

                _finalContext.Clientes.Add(objeto);
                _finalContext.SaveChanges();
                return CreatedAtAction(nameof(FiltrarID), new { idCliente = objeto.ClienteId }, objeto);

            }
            catch(Exception ex) 
            {
                return BadRequest($"Error al crear el cliente: {ex.Message}");
            }
        }

        [HttpPatch]
        [Route("EditarObjeto")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateCliente([FromBody] Cliente objeto)
        {
            try
            {
                var existingCliente = await _finalContext.Clientes.FindAsync(objeto.ClienteId);

                if (existingCliente == null)
                {
                    return NotFound($"Cliente con ID {objeto.ClienteId} no encontrado.");
                }

                // Modificar las propiedades del cliente existente con los valores del objeto recibido
                existingCliente.Nombre = objeto.Nombre;
                existingCliente.Gmail = objeto.Gmail;
                existingCliente.Contraseña = objeto.Contraseña;
                
                // Guardar los cambios en la base de datos
                _finalContext.SaveChanges();

                // Retornar el cliente actualizado
                return Ok(existingCliente);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al actualizar el cliente: {ex.Message}");
            }
        }

        [HttpDelete]
        [Route("EliminarObjeto")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteCliente(string Gmail)
        {
            try
            {
                // Buscar el cliente por su dirección de correo electrónico
                Cliente cliente = _finalContext.Clientes.FirstOrDefault(c => c.Gmail == Gmail);

                if (cliente == null)
                {
                    return NotFound($"Cliente con Gmail {Gmail} no encontrado.");
                }

                // Eliminar el cliente de la base de datos
                _finalContext.Clientes.Remove(cliente);
                _finalContext.SaveChanges();

                return Ok("Cliente eliminado exitosamente.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al eliminar el cliente: {ex.Message}");
            }
        }


        [HttpDelete]
        [Route("EliminarPorID")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteClienteByID(int ID)
        {
            try
            {
                // Buscar el cliente por su dirección de correo electrónico
                Cliente cliente = _finalContext.Clientes.FirstOrDefault(c => c.ClienteId == ID);

                if (cliente == null)
                {
                    return NotFound($"Cliente con Gmail {ID} no encontrado.");
                }

                // Eliminar el cliente de la base de datos
                _finalContext.Clientes.Remove(cliente);
                _finalContext.SaveChanges();

                return Ok("Cliente eliminado exitosamente.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al eliminar el cliente: {ex.Message}");
            }
        }
    }
}
