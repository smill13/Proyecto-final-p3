﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Proyecto_final_p3.Models;

namespace Proyecto_final_p3.Controllers
{
    [EnableCors("ReglasCors")]
    [Route("api/[controller]")]
    [ApiController]
    public class HotelesController : ControllerBase
    {
        readonly P3FinalContext _finalContext;

        public HotelesController(P3FinalContext finalContext)
        {
            _finalContext = finalContext;

        }

        [HttpGet]
        [Route("Get_Hoteles")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetHoteles()
        {
            List<Hoteles> listHoteles = new List<Hoteles>();
            listHoteles = await _finalContext.Hoteles.ToListAsync();
            return Ok(listHoteles);
        }

        [HttpGet]
        [Route("Filtrar_ID")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> FiltrarID(int idhotele)
        {
            try
            {
                Hoteles hoteles = await _finalContext.Hoteles.FirstOrDefaultAsync(p => p.HotelId == idhotele);

                if (hoteles == null)
                {
                    return NotFound("Hotele no encontrado");
                }

                return Ok(hoteles);
            }
            catch (Exception ex)
            {
                // Registra el error si es necesario
                return StatusCode(StatusCodes.Status500InternalServerError, "Error interno del servidor");
            }
        }

        [HttpPost]
        [Route("CrearObjeto")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CrearHoteles([FromBody] Hoteles objeto)
        {
            try
            {

                _finalContext.Hoteles.Add(objeto);
                _finalContext.SaveChanges();
                return CreatedAtAction(nameof(FiltrarID), new { HotelId = objeto.HotelId}, objeto);

            }
            catch (Exception ex)
            {
                return BadRequest($"Error al crear el cliente: {ex.Message}");
            }
        }

        [HttpPatch]
        [Route("EditarObjeto")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateHoteles([FromBody] Hoteles objeto)
        {
            try
            {
                var existingHotel = await _finalContext.Hoteles.FindAsync(objeto.HotelId);

                if (existingHotel == null)
                {
                    return NotFound($"Hotel con ID {objeto.HotelId} no encontrado.");
                }

                // Modificar las propiedades del cliente existente con los valores del objeto recibido
                existingHotel.Nombre = objeto.Nombre;
                existingHotel.Direccion = objeto.Direccion;
                existingHotel.Ciudad = objeto.Ciudad;
                existingHotel.Pais = objeto.Pais;
                existingHotel.Telefono = objeto.Telefono;
                existingHotel.Estacionamiento = objeto.Estacionamiento;

                // Guardar los cambios en la base de datos
                _finalContext.SaveChanges();

                // Retornar el cliente actualizado
                return Ok(existingHotel);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al actualizar el cliente: {ex.Message}");
            }
        }

        [HttpDelete]
        [Route("EliminarObjeto")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult DeleteHotel(int HotelId)
        {
            try
            {
                // Buscar el hotel por su id
                Hoteles hotel = _finalContext.Hoteles.FirstOrDefault(c => c.HotelId == HotelId);

                if (hotel == null)
                {
                    return NotFound($"Hotel con HotelId {HotelId} no encontrado.");
                }

                // Eliminar el hotel de la base de datos
                _finalContext.Hoteles.Remove(hotel);
                _finalContext.SaveChanges();

                return Ok("Hotel eliminado exitosamente.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al eliminar el hotel: {ex.Message}");
            }
        }

    }
}
