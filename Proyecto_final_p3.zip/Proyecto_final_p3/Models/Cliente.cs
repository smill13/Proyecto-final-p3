﻿using System;
using System.Collections.Generic;
using Proyecto_final_p3.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Text.Json.Serialization;

namespace Proyecto_final_p3.Models;

public partial class Cliente
{

    public int ClienteId { get; set; }

    public string? Nombre { get; set; }

    public string? Gmail { get; set; }

    public string? Contraseña { get; set; }
    [JsonIgnore]
    public virtual ICollection<Reservas> Reservas { get; set; } = new List<Reservas>();
}


public static class ClienteEndpoints
{
	public static void MapClienteEndpoints (this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/api/Cliente").WithTags(nameof(Cliente));

        group.MapGet("/", async (P3FinalContext db) =>
        {
            return await db.Clientes.ToListAsync();
        })
        .WithName("GetAllClientes")
        .WithOpenApi();

        group.MapGet("/{id}", async Task<Results<Ok<Cliente>, NotFound>> (int clienteid, P3FinalContext db) =>
        {
            return await db.Clientes.AsNoTracking()
                .FirstOrDefaultAsync(model => model.ClienteId == clienteid)
                is Cliente model
                    ? TypedResults.Ok(model)
                    : TypedResults.NotFound();
        })
        .WithName("GetClienteById")
        .WithOpenApi();

        group.MapPut("/{id}", async Task<Results<Ok, NotFound>> (int clienteid, Cliente cliente, P3FinalContext db) =>
        {
            var affected = await db.Clientes
                .Where(model => model.ClienteId == clienteid)
                .ExecuteUpdateAsync(setters => setters
                  .SetProperty(m => m.ClienteId, cliente.ClienteId)
                  .SetProperty(m => m.Nombre, cliente.Nombre)
                  .SetProperty(m => m.Gmail, cliente.Gmail)
                  .SetProperty(m => m.Contraseña, cliente.Contraseña)
                  );
            return affected == 1 ? TypedResults.Ok() : TypedResults.NotFound();
        })
        .WithName("UpdateCliente")
        .WithOpenApi();

        group.MapPost("/", async (Cliente cliente, P3FinalContext db) =>
        {
            db.Clientes.Add(cliente);
            await db.SaveChangesAsync();
            return TypedResults.Created($"/api/Cliente/{cliente.ClienteId}",cliente);
        })
        .WithName("CreateCliente")
        .WithOpenApi();

        group.MapDelete("/{id}", async Task<Results<Ok, NotFound>> (int clienteid, P3FinalContext db) =>
        {
            var affected = await db.Clientes
                .Where(model => model.ClienteId == clienteid)
                .ExecuteDeleteAsync();
            return affected == 1 ? TypedResults.Ok() : TypedResults.NotFound();
        })
        .WithName("DeleteCliente")
        .WithOpenApi();
    }
}