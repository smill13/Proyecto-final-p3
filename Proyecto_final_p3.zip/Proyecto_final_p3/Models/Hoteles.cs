﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
namespace Proyecto_final_p3.Models;


public partial class Hoteles
{

    public int HotelId { get; set; }

    public string Nombre { get; set; } = null!;

    public string Direccion { get; set; } = null!;

    public string? Ciudad { get; set; }

    public string? Pais { get; set; }

    public string? Telefono { get; set; }

    public string? Estacionamiento { get; set; }
    [JsonIgnore]

    public virtual ICollection<Reservas> Reservas { get; set; } = new List<Reservas>();
}
