﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Proyecto_final_p3.Models;

public partial class Reservas
{

    public int ReservaId { get; set; }
    
    public int? ClienteId { get; set; }
    
    public int? HotelId { get; set; }

    public DateOnly FechaInicio { get; set; }

    public DateOnly FechaFin { get; set; }

    public decimal? PrecioTotal { get; set; }

    public string? Estado { get; set; }

    public virtual Cliente? Cliente { get; set; }

    public virtual Hoteles? Hotel { get; set; }
}
